package frontEndTesting;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SavingLoanReq {
	WebDriver driver;
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", 
				"F:\\Mphasis\\chromedriver.exe");
		driver =  new ChromeDriver(); 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
		driver.get("http://localhost:4200/login");
	}
	
	@Test
	public  void requestloanSaving() throws InterruptedException {
		driver.findElement(By.cssSelector("input[name='email']")).sendKeys("shubham@gmail.com");
		driver.findElement(By.cssSelector("input[name='password']")).sendKeys("shubham123");
		driver.findElement(By.id("loginButton")).click();
		driver.findElement(By.id("chequebookRequestLink")).click();
		driver.findElement(By.id("loanRequestSaving")).click();
		driver.findElement(By.id("accountType")).click();
		
		//driver.findElement(By.xpath("//select[@id=\"accountType\"]/option[1]")).click();
		driver.findElement(By.xpath("//select[@id=\"accountType\"]/option[2]")).click();
		//driver.findElement(By.xpath("//select[@id=\"chequetype\"]/option[1]")).click();
		//driver.findElement(By.xpath("//select[@id=\"chequetype\"]/option[2]")).click();
		//driver.findElement(By.id("individual")).click();
		
		driver.findElement(By.id("description")).sendKeys("Apply for Home loan");;

		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

		Thread.sleep(1000L);
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		alert.accept();

	}
	
	@AfterTest
	public void cleanUp() {
		driver.close();
	}

}
